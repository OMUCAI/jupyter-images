import requests
import shutil
from pathlib import Path
from IPython.display import Video

class SCGRobot:
    BASE_URL = "http://10.35.149.11:8000"
    def __init__(self, goal: tuple = (5, 5), obstacle: list[tuple] = [(1,1)], action: list[int] = []) -> None:
        self.goal = goal
        self.obstacle = obstacle
        self.action = action
    
    def _build_task(self) -> dict:
        task = {
            "event": "task",
            "data": {
                "finish": self.goal,
                "obstacle": self.obstacle,
                "actions": self.action,
            }
        }
        return task
    
    def send_request(self) -> str:
        task = self._build_task()
        r = requests.post(self.BASE_URL + "/register", json=task, timeout=5)
        if r.status_code == 200:
            return r.text
        else:
            print(r.text)
            return False
    
    @classmethod
    def get_media(cls, task_id: str, filename: str = None) -> str:
        res = requests.get(cls.BASE_URL + f"/result/{task_id}", stream=True)
        if res.status_code == 200:
            path = Path(f"{filename}.mp4" if filename is not None else f"{task_id}.mp4")
            with open(path, 'wb') as file:
                res.raw.decode_content = True
                shutil.copyfileobj(res.raw, file)
            return Video(path)
        else:
            print(res.text)
            return False

