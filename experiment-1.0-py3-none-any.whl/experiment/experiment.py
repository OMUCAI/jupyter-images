from .scg_robot import SCGRobot
from typing import List
import json

def start(goal, obstacle: List, action: List[int], Download, scene: int = 1):
    scgrobot = SCGRobot(goal=goal, obstacle=obstacle, action = action, scene = scene)
    try:
        response = (scgrobot.send_request())
    except:
        print("Please try again few minutes later...")
        return
    else:
        print(response)

    if Download:
        response = json.loads(response)
        print("now recording...")
        media = SCGRobot.get_media(response["task_id"])
        print("finish recording!")
        return media
    
def get_media(task_id: str):
    return SCGRobot.get_media(task_id)

def maze(action, goal = 9, obstacle = [], if_download = True):
    #
    #import experiment
    #experiment.maze(action, goal, obstacle, )
    #
    #Parameters
    #----------------------
    #action: List[int]
    # commands for the robot
    #
    #goal : tuple or int
    # coordinate or number of the goal
    #
    #obstacle: List[tuple] or List[int]
    # list of coordinates or numbers of places where the robot can not go
    
    #
    #Download: bool
    # option
    #-----------------------
    #
    if isinstance(goal, (tuple,int)):
        if isinstance(goal, int):
            x = (goal - 1) // 3 + 1
            y = (goal - 1) % 3 + 1
            goal = (x, y)
    else:
        print("type error")
        return
    
    for i in range(len(obstacle)):
        if isinstance(obstacle[i], tuple):
            continue
        elif isinstance(obstacle[i], int):
            x = (obstacle[i] - 1) // 3 + 1
            y = (obstacle[i] - 1) % 3 + 1
            obstacle[i] = (x, y)
        else:
            print("type error")
            return
        
    for i in range(len(obstacle)):
        if obstacle[i] == (1,1) or obstacle[i] == goal:
            print("value error")
            return
    
    action = check_safety_m(action, obstacle)
    return(start(goal, obstacle, action, if_download, 1))

def warehouse(action, goal = 9, obstacle: List = [], if_download = True):
    if isinstance(goal, (tuple,int)):
        if isinstance(goal, int):
            x = (goal - 1) // 3 + 1
            y = (goal - 1) % 3 + 1
            goal = (x, y)
    else:
        print("type error")
        return
    
    for i in range(len(obstacle)):
        if isinstance(obstacle[i], tuple):
            continue
        elif isinstance(obstacle[i], int):
            x = (obstacle[i] - 1) // 3 + 1
            y = (obstacle[i] - 1) % 3 + 1
            obstacle[i] = (x, y)
        else:
            print("type error")
            return
        
    for i in range(len(obstacle)):
        if obstacle[i] == (1,1) or obstacle[i] == goal:
            print("value error")
            return
    
    action = check_safety_w(action, obstacle)
    return(start(goal, obstacle, action, if_download,2))

def googlemap(action, goal: int = 9, obstacle: List = [], if_download = True):
    passlist = [(1,2),(2,3),(1,4),(2,5),(3,6),(4,5),(5,6),(4,7),(6,8),(7,8),(7,9),(8,9),
               (2,1),(3,2),(4,1),(5,2),(6,3),(5,4),(6,5),(7,4),(8,6),(8,7),(9,7),(9,8)]
    
    if isinstance(goal, int):
        if goal < 0 or 9 < goal:
            print("value error")
            return
        goal = (goal, 0)
    else:
        print("type error")
        return
    
    for i in range(len(obstacle)):
        if isinstance(obstacle[i], tuple):
            if not obstacle[i] in passlist:
                print("value error")
                return
        elif isinstance(obstacle[i], int):
            if obstacle[i] < 0 or 9 < obstacle[i]:
                print("value error")
                return
            obstacle[i] = (obstacle[i], 0)
        else:
            print("tupe error")
            return
        
        if obstacle[i] == (1, 0) or obstacle[i] == goal:
            print("value error")
            return
    
    action = check_safety_g(action, obstacle)
    return(start(goal, obstacle, action, if_download, 3))
    
def check_safety_m(action, obstacle):
    checked = []
    x = 1
    y = 1
    for i in range(len(action)):
        n = action[i] % 10
        if n == 1:
            x = x - 1
        elif n == 3:
            y = y + 1
        elif n == 5:
            x = x + 1
        elif n == 7:
            y = y - 1
        if x < 1 or x > 3 or y < 1 or y > 3:
            print("unsafe path, please check again!")
            return checked

        checked.append(action[i])
        posi = (x, y)
        if posi in obstacle:
            print("unsafe path, please check again!")
            return checked
    
    return checked

def check_safety_w(action, obstacle):
    checked = []
    x = 1
    y = 1
    safe = True
    for i in range(len(action)):
        n = action[i] % 10
        if n == 1:
            if (x - 1) * 3 + y == 8:
                safe = False
            x = x - 1
        elif n == 3:
            y = y + 1
        elif n == 5:
            if (x - 1) * 3 + y == 2:
                safe = False
            x = x + 1
        elif n == 7:
            y = y - 1
        if x < 1 or x > 3 or y < 1 or y > 3:
            safe = False
            
        if not safe:
            print("unsafe path, please check again!")
            return checked

        checked.append(action[i])
        posi = (x, y)
        if posi in obstacle:
            print("unsafe path, please check again!")
            return checked
    
    return checked

def check_safety_g(action, obstacle):
    route = [[],[0,2,4,0],[0,3,5,1],[0,0,6,2],[1,5,7,0],[2,6,0,4],[3,0,8,5],[4,8,9,0],[6,0,9,7],[8,0,0,7]]
    posi = 1
    checked = []
    for i in range(len(action)):
        n = (action[i] % 10) // 2
        next_posi = route[posi][n]
        if not next_posi:
            print("unsafe path, please check again!")
            return checked
        
        for j in range(len(obstacle)):
            obj = obstacle[j]
            if (next_posi, 0) == obj:
                checked.append(action[i])
                print("unsafe pass, please check again!")
                return checked
            elif (posi, next_posi) == obj or (next_posi, posi) == obj:
                print("unsafe path, please check again!")
                return checked
        posi = next_posi
        checked.append(action[i])
        
    return checked

def introduction():
    print("""
    Function
    --------------------------------------------
    maze(action, goal, obstacle, if_download)
    warehouse(action, goal, obstacle, if_ownload)
    googlemap(action, goal, obstacle, if_ownload)
    get_media(task_id)
    --------------------------------------------
    
    
    
    maze(action, goal, obstacle, if_download)
    
    Parameter
    --------------------------------------------
    action: List[int]
    (list of integers, each representing a robot action)
    
    goal: 2D-coordinate or int
    (2D coordinate or location number of goal location)
    
    obstacle: List[2D-coordinate] or List[int]
    (list of 2D coordinates or location numbers of obstacle locations)
    
    if_download: bool
    (True/False. True: download video; False: no video downloading)
    --------------------------------------------
    
    
    
    warehouse(action, goal, obstacle, if_download)
    
    Parameter
    --------------------------------------------
    action: List[int]
    (list of integers, each representing a robot action)
    
    goal: 2D-coordinate or int
    (2D coordinate or location number of goal location)
    
    obstacle: List[2D-coordinate] or List[int]
    (list of 2D coordinates or location numbers of obstacle locations)
    
    if_download: bool
    (True/False. True: download video; False: no video downloading)
    --------------------------------------------
    
    
    
    googlemap(action, goal, obstacle, if_download)
    
    Parameter
    --------------------------------------------
    action: List[int]
    (list of integers, each representing a robot action)
    
    goal : int
    (location number of goal location)
    
    obstacle: List[int] or List[pair of location numbers]
    (list of location numbers or pair of location numbers of obstacle locations)
    
    if_download: bool
    (True/False. True: download video; False: no video downloading)
    --------------------------------------------
    
    
    
    get_media(task_id)
     you can get video of your experiment
    
    Parameter
    --------------------------------------------
    task_id: string
    (id of your experiment)
    --------------------------------------------
    
    """)
